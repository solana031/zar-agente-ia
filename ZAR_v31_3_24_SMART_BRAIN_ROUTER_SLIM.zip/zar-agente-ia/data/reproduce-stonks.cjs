const fs=require('fs'), cp=require('child_process');
const {chromium}=require('playwright');
(async()=>{
const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
for(const ref of ['bee7f11','e7e35af']){
 const html=cp.execFileSync('git',['show',ref+':app/templates/index.html'],{encoding:'utf8',maxBuffer:4000000});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}); const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',route=>{const u=new URL(route.request().url());if(u.pathname==='/')return route.fulfill({contentType:'text/html',body:html});if(u.pathname.endsWith('.js'))return route.fulfill({contentType:'application/javascript',body:fs.existsSync('app'+u.pathname)?fs.readFileSync('app'+u.pathname,'utf8'):''});return route.fulfill({contentType:'application/json',body:JSON.stringify({ok:true,paused:true,mode:'paper',signals:[],positions:[],orders:[],audit:[]})})});
 await page.goto('http://zar.test/');await page.evaluate(()=>showStonks());await page.waitForTimeout(800);
 console.log(ref,JSON.stringify(await page.evaluate(()=>Object.fromEntries(['panelBody','zarStonksApp','zsChatDock','zsTab-dashboard','zsTab-risk'].map(id=>{const e=document.getElementById(id),r=e.getBoundingClientRect(),s=getComputedStyle(e);return [id,{parent:e.parentElement.id||e.parentElement.className,w:r.width,h:r.height,x:r.x,y:r.y,display:s.display}]})))),errors);
 await page.close();
}await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
