from pathlib import Path
p=Path('tests/stonks-rendering.cjs');s=p.read_text(encoding='utf-8-sig').rstrip()+'\n'
s=s.replace('      await checkLayout();\n      await checkResponsive();\n      // Real clicks', '''      await checkLayout();
      await checkResponsive();
      if(viewport.width<=900){
        // Exercise resize/orientation while the same window remains open.
        await page.setViewportSize({width:800,height:430});
        await checkLayout();await checkResponsive();
        await page.setViewportSize(viewport);
        await checkLayout();await checkResponsive();
        if(process.env.ZAR_TEST_SCREENSHOTS)await page.screenshot({path:`data/stonks-${viewport.width}.png`});
      }
      // Real clicks''')
s=s.replace("      assert.equal(await page.locator('#zsManagedPositionsBody tr').count(), 1);", '''      assert.equal(await page.locator('#zsManagedPositionsBody tr').count(), 1);
      if(viewport.width<=900){
        const wrap=page.locator('#zsManagedPositionsBody').locator('xpath=../..');
        assert.equal(await wrap.evaluate(e=>{e.scrollLeft=100;return e.scrollLeft>0}),true,'wide table scrolls locally');
        await checkResponsive();
      }''')
p.write_text(s,encoding='utf-8')
