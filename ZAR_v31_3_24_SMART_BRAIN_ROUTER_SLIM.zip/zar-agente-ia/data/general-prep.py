from pathlib import Path
p=Path('app/templates/index.html');s=p.read_text(encoding='utf-8')
s=s.replace("function toggleZarMenu(){if(window.innerWidth<=720)","function toggleZarMenu(){if(window.innerWidth<=1100)")
s=s.replace("function closePanel(){panel.style.display='none';", "function closePanel(){document.body.classList.remove('zar-panel-open');panel.style.display='none';")
s=s.replace("function openPanel(){installPanelInteraction();", "function openPanel(){document.body.classList.add('zar-panel-open');installPanelInteraction();")
s=s.replace('31.3.22','31.3.23')
s+='\n<link rel="stylesheet" href="/static/ui-polish.css?v=31.3.23">\n<script src="/static/ui-polish.js?v=31.3.23"></script>\n'
p.write_text(s,encoding='utf-8')
for n in ['VERSION','VERSION.txt','app/VERSION.txt']:Path(n).write_text('31.3.23\n',encoding='utf-8')
p=Path('tests/stonks-rendering.cjs');s=p.read_text(encoding='utf-8').replace('31.3.22','31.3.23');s=s.replace("        if (url.pathname === '/static/skills.js')", "        if (['/static/ui-polish.css','/static/ui-polish.js'].includes(url.pathname)) return route.fulfill({contentType:url.pathname.endsWith('.css')?'text/css':'application/javascript',body:fs.readFileSync('app'+url.pathname)});\n        if (url.pathname === '/static/skills.js')");p.write_text(s,encoding='utf-8')
