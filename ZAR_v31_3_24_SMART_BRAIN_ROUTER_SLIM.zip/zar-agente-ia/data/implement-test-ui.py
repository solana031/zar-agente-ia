from pathlib import Path
p=Path('app/templates/index.html');s=p.read_text(encoding='utf-8')
needle='<div id="zsLifecycleMeta" class="zsInfo" style="margin-top:9px">Sin posiciones ZAR gestionadas.</div>'
assert s.count(needle)==1
s=s.replace(needle,needle+'''<div class="zsInfo" style="margin-top:9px"><b>PRUEBA PAPER · nunca Live</b><p>Entrada mínima de 1 USD, con los límites Risk actuales. Espera el fill real y usa «Cerrar prueba Paper» para comprobar el cierre sin alterar tus SL/TP. Las órdenes se envían a tu cuenta simulada.</p><div class="zsControls"><div class="zsField"><label for="zsLifecycleTestSymbol">Símbolo fraccionable</label><input id="zsLifecycleTestSymbol" value="AAPL" maxlength="20"></div></div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:9px"><button id="zsLifecycleTestStart" class="zsBtn gold" disabled onclick="zsStartLifecycleTest()">Probar ciclo Paper</button><button id="zsLifecycleTestClose" class="zsBtn" disabled onclick="zsCloseLifecycleTest()">Cerrar prueba Paper</button></div><div id="zsLifecycleTestState" role="status" aria-live="polite" style="margin-top:9px">Verificando requisitos de la prueba Paper…</div><ol id="zsLifecycleTestSteps"></ol></div>''')
pos=s.index('function zsRenderManagedPositions(')
s=s[:pos]+'''let zsLifecycleTestState=null, zsLifecycleTestBusy=false, zsLifecycleTestRequestId=null;
function zsRenderLifecycleTest(j){
  zsLifecycleTestState=j;
  const t=j.lifecycle_test||{}, ready=!!(j.paper_connected&&j.engine_owned_by_current_user&&j.autonomous_engine&&j.mode==='paper'&&j.execution_mode==='paper_auto'&&j.position_lifecycle_enabled&&!j.paused&&!j.revoked);
  const start=document.getElementById('zsLifecycleTestStart'), close=document.getElementById('zsLifecycleTestClose'), symbol=document.getElementById('zsLifecycleTestSymbol');
  if(start)start.disabled=zsLifecycleTestBusy||!ready||!!t.active;
  if(close)close.disabled=zsLifecycleTestBusy||!ready||!t.can_close;
  if(symbol)symbol.disabled=zsLifecycleTestBusy||!!t.active;
  const status=document.getElementById('zsLifecycleTestState');
  const text='PRUEBA PAPER · '+(t.symbol?t.symbol+' · ':'')+(t.status||'SIN_PRUEBA')+(t.error?' · '+t.error:'')+(!ready?' · Requiere conexión Paper verificada, motor propio activo, Paper automático, gestión activa y sin Pausa/Revocación.':'');
  if(status&&status.textContent!==text)status.textContent=text;
  const list=document.getElementById('zsLifecycleTestSteps');if(!list)return;
  const labels=[['TEST_LIFECYCLE_STARTED','Intención TEST_LIFECYCLE persistida'],['TEST_ENTRY_REQUESTED','Entrada Paper solicitada'],['TEST_POSITION_DETECTED','Fill y posición propios confirmados; datos en la tabla'],['TEST_CLOSE_REQUESTED','Cierre Paper solicitado'],['TEST_POSITION_CLOSED','Posición cerrada por reconciliación'],['TEST_LIFECYCLE_OK','Ciclo Paper verificado']];
  while(list.children.length<labels.length)list.appendChild(document.createElement('li'));
  labels.forEach(([event,label],i)=>{const done=(t.steps||[]).some(step=>step.event===event);const value=(done?'✓ ':'○ ')+label;if(list.children[i].textContent!==value)list.children[i].textContent=value});
}
async function zsRunLifecycleTest(action){
  if(zsLifecycleTestBusy)return;
  const button=document.getElementById(action==='start'?'zsLifecycleTestStart':'zsLifecycleTestClose');if(!button||button.disabled)return;
  zsLifecycleTestBusy=true;zsRenderLifecycleTest(zsLifecycleTestState||{});
  try{
    const opening=action==='start';
    const ok=await zsOpenConfirm(opening?'Enviarás una entrada TEST_LIFECYCLE de 1 USD a Alpaca Paper. Se comprobarán Risk y ownership.':'Solicitarás el cierre de la posición TEST_LIFECYCLE mediante el motor y los límites Risk actuales.',opening?'Probar ciclo Paper':'Cerrar prueba Paper','PRUEBA PAPER · No utiliza Live.',opening?'Iniciar prueba Paper':'Cerrar prueba Paper','Cancelar','primary','🧪','No cambia tus SL/TP. Pausa y Revocación bloquean nuevos envíos.');
    if(!ok)return;
    let payload={confirm:true};
    if(opening){
      // Keep this key on an uncertain response so another click cannot create another entry.
      zsLifecycleTestRequestId=zsLifecycleTestRequestId||crypto.randomUUID();
      payload.request_id=zsLifecycleTestRequestId;payload.symbol=document.getElementById('zsLifecycleTestSymbol')?.value.trim().toUpperCase()||'AAPL';
    }else payload.id=zsLifecycleTestState?.lifecycle_test?.id;
    const response=await fetch('/api/stonks/lifecycle-test/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const result=await response.json();
    if(!result.ok){if(opening&&response.status<500&&result.lifecycle_test&&!result.lifecycle_test.active)zsLifecycleTestRequestId=null;throw new Error(result.error||'Prueba Paper no confirmada')}
    if(opening)zsLifecycleTestRequestId=null;
    await zsRefreshStatus();
  }catch(e){await zsOpenNotice(e.message||'No se pudo confirmar la prueba Paper. Consulta el estado antes de reintentar.','Prueba Paper','Se conserva la reconciliación y la protección contra duplicados.','Entendido','🧪','Solo Alpaca Paper.')}finally{zsLifecycleTestBusy=false;zsRenderLifecycleTest(zsLifecycleTestState||{})}
}
function zsStartLifecycleTest(){return zsRunLifecycleTest('start')}
function zsCloseLifecycleTest(){return zsRunLifecycleTest('close')}
'''+s[pos:]
s=s.replace('zsRenderManagedPositions(j.managed_positions);const paused', 'zsRenderManagedPositions(j.managed_positions);zsRenderLifecycleTest(j);const paused')
s=s.replace('v31.3.20','v31.3.21')
p.write_text(s,encoding='utf-8')
for name in ['VERSION','VERSION.txt','app/VERSION.txt']:
 Path(name).write_text('31.3.21\n',encoding='utf-8')
p=Path('tests/stonks-rendering.cjs');s=p.read_text(encoding='utf-8').replace("'31.3.20'","'31.3.21'");p.write_text(s,encoding='utf-8')
p=Path('app/stonks_lifecycle.py');s=p.read_text(encoding='utf-8')
s=s.replace("        if record.get('test_error') == reason:\n            return\n        record['test_error'] = reason", "        record['test_error'] = reason\n        if record.get('test_last_error_logged') == reason:\n            return\n        record['test_last_error_logged'] = reason")
s=s.replace("                exit_orders.append((intent, order))", "                exit_orders.append((intent, order))\n                if order:\n                    test_event(record, 'TEST_CLOSE_REQUESTED', audit, intent['trigger'], intent['qty'], order.get('filled_avg_price'))")
p.write_text(s,encoding='utf-8')
