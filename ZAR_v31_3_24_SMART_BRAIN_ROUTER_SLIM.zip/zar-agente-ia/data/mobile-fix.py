from pathlib import Path
p=Path('app/templates/index.html')
s=p.read_text(encoding='utf-8').replace('31.3.21','31.3.22')
s+='''
<style id="zar-stonks-mobile-31-3-22">
/* Scoped overrides: desktop window and other ZAR workspaces retain their layout. */
@media(max-width:900px){
  body:has(#panel.zsFloatingWindow) #chatContent .composer,
  body:has(#panel.zsFloatingWindow) #chatContent .quick,
  body:has(#panel.zsFloatingWindow) .chatScrollControls{visibility:hidden!important;pointer-events:none!important;}
  #panel.panel.zsFloatingWindow{inset:0!important;width:100%!important;max-width:100%!important;min-width:0!important;height:100dvh!important;min-height:0!important;max-height:100dvh!important;resize:none!important;border:0!important;border-radius:0!important;}
  #panel.zsFloatingWindow>.zarPanelDragHandle{display:none!important;}
  #panel.zsFloatingWindow #panelBody,#panel.zsFloatingWindow .zarStonksPanel{min-width:0!important;max-width:100%!important;border-radius:0!important;}
  #zarStonksApp *{box-sizing:border-box;}
  #zarStonksApp .zsTop{flex:0 0 auto;position:static;display:grid;grid-template-columns:minmax(0,1fr) auto;gap:5px;padding:calc(6px + env(safe-area-inset-top)) max(8px,env(safe-area-inset-right)) 6px max(8px,env(safe-area-inset-left));min-height:0;}
  #zarStonksApp .zsBrand{min-width:0;gap:6px;}
  #zarStonksApp .zsLogo{width:28px;height:28px;flex:0 0 28px;}
  #zarStonksApp .zsTitle{font-size:14px;white-space:nowrap;}
  #zarStonksApp .zsSub{display:none;}
  #zarStonksApp .zsStatus{display:flex;grid-column:1/-1;grid-row:2;flex-wrap:wrap;gap:6px;font-size:10px;}
  #zarStonksApp .zsStatus:before{content:'PAPER';color:#f3c56b;font-weight:800;}
  #zarStonksApp .zsTopActions{gap:3px;}
  #zarStonksApp .zsTopActions .zsBtn{min-width:32px;min-height:36px;padding:6px;font-size:12px;}
  #zarStonksApp .zsTopActions .zsBtn span,#zarStonksApp .zsMaxBtn{display:none;}
  #panel.zsFloatingWindow .zsWorkspace{display:flex;flex-direction:column;overflow:hidden!important;min-width:0;}
  #zarStonksApp .zsSide{display:block;flex:0 0 auto;min-width:0;max-width:100%;padding:4px 8px;border-right:0;border-bottom:1px solid #3d3128;}
  #zarStonksApp .zsSide>.zsSectionLabel,#zarStonksApp .zsSide>.zsInfo,#zarStonksApp .zsSideMeta{display:none;}
  #zarStonksApp .zsNav{flex-direction:row;overflow-x:auto;overscroll-behavior-x:contain;touch-action:pan-x;max-width:100%;padding-bottom:3px;}
  #zarStonksApp .zsNav button{flex:0 0 auto;white-space:nowrap;min-height:38px;font-size:11px;}
  #zarStonksApp .zsNav button.active{box-shadow:inset 0 -3px #d4af37;}
  #zarStonksApp .zsSideCard{display:flex;align-items:center;gap:8px;margin:2px 0 0;padding:3px 6px;border:0;background:transparent;}
  #zarStonksApp .zsMoney{font-size:13px;margin:0;overflow-wrap:anywhere;min-width:0;}
  #panel.zsFloatingWindow .zsMain{flex:1 1 auto;min-width:0;width:100%;overflow-x:hidden!important;overflow-y:auto!important;overscroll-behavior-y:contain;padding:9px;}
  #zarStonksApp .zsMain *{min-width:0;}
  #zarStonksApp .zsCards,#zarStonksApp .zsPortfolioStrip{grid-template-columns:repeat(2,minmax(0,1fr));}
  #zarStonksApp .zsCardValue,#zarStonksApp .zsLiveValue{font-size:clamp(12px,3.5vw,18px);overflow-wrap:anywhere;}
  #zarStonksApp .zsCardNote{font-size:10px;}
  #zarStonksApp .zsTabTitle,#zarStonksApp .zsChartHead,#zarStonksApp .zsRiskLine{flex-wrap:wrap;}
  #zarStonksApp .zsInfo,#zarStonksApp .meta,#zarStonksApp .zsBadge{overflow-wrap:anywhere;}
  #zarStonksApp .zsControls,#zarStonksApp .zsSignalControls{grid-template-columns:1fr!important;}
  #zarStonksApp .zsField input,#zarStonksApp .zsField select{width:100%;max-width:100%;font-size:16px;}
  #zarStonksApp .zsSignalAuto{flex-wrap:wrap;}
  #zarStonksApp .zsCanvasWrap{width:100%;height:235px;flex:none;}
  #zarStonksApp .zsCanvas{width:100%;max-width:100%;height:100%;}
  #zarStonksApp .zsPortfolioTableWrap,#zarStonksApp .zsSignalTableWrap,#zarStonksApp div:has(>.zsTable){max-width:100%;overflow-x:auto;overscroll-behavior-x:contain;}
  #zarStonksApp .zsTable{min-width:600px;}
  #panel.zsFloatingWindow .zsChatHistory{max-height:24dvh!important;overflow-wrap:anywhere;}
  #panel.zsFloatingWindow .zsBottom{flex:0 0 auto!important;height:auto!important;min-height:60px!important;max-height:none!important;padding:8px max(8px,env(safe-area-inset-right)) calc(8px + env(safe-area-inset-bottom)) max(8px,env(safe-area-inset-left))!important;gap:5px;flex-wrap:nowrap!important;}
  #zarStonksApp .zsBottom input{order:0;flex:1 1 0!important;width:0;font-size:16px;padding:10px 8px;}
  #zarStonksApp .zsBottom .zsBtn{order:0;flex:0 0 40px;min-height:42px;padding:7px;}
  #zarStonksApp .zsChips{display:none;}
  #zarStonksApp .zsConfirmModal{padding:8px;}
  #zarStonksApp .zsConfirmCard{max-height:calc(100dvh - 24px);overflow-y:auto;width:100%;}
}
@media(max-width:340px){
  #zarStonksApp .zsCards,#zarStonksApp .zsPortfolioStrip{grid-template-columns:minmax(0,1fr);}
  #zarStonksApp .zsTopActions .zsBtn{min-width:28px;padding:4px;}
}
</style>
'''
# Accessible names survive hiding button labels in compact headers.
s=s.replace('onclick="zsRefreshStatus()">↻','aria-label="Actualizar estado" onclick="zsRefreshStatus()">↻').replace('id="zsPauseBtn" onclick=', 'id="zsPauseBtn" aria-label="Pausar o reanudar" onclick=').replace('id="zsRevokeBtn" onclick=', 'id="zsRevokeBtn" aria-label="Revocar" onclick=').replace('class="zsBtn zsCloseBtn" onclick=', 'class="zsBtn zsCloseBtn" aria-label="Cerrar Stonks" onclick=')
p.write_text(s,encoding='utf-8')
for name in ['VERSION','VERSION.txt','app/VERSION.txt']:
 Path(name).write_text('31.3.22\n',encoding='utf-8')
p=Path('tests/stonks-rendering.cjs');s=p.read_text(encoding='utf-8').replace('31.3.21','31.3.22')
s=s.replace('{width: 390, height: 844}', '{width: 360, height: 800}, {width: 390, height: 844}, {width: 412, height: 915}, {width: 430, height: 932}, {width: 768, height: 1024}')
a=s.index('      if(viewport.width<720){');b=s.index("      await page.locator('.zsChatToggle').click();",a)
s=s[:a]+s[b:]
s=s.replace("await page.evaluate(() => zsTab('risk', document.querySelector('[data-zstab=\"risk\"]')));", "await page.locator('[data-zstab=\"risk\"]').click();")
p.write_text(s,encoding='utf-8')
