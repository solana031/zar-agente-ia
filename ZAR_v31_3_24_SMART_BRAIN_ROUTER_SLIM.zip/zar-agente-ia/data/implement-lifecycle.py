from pathlib import Path
p=Path('app/main.py');s=p.read_text(encoding='utf-8')
s=s.replace('import uuid\n', 'import uuid\nfrom functools import wraps\nfrom contextlib import contextmanager\nfrom . import stonks_lifecycle\n')
pos=s.index('def _stonks_file():')
s=s[:pos]+'''# Serialize worker and HTTP mutations across threads/processes on the persistent volume.
_STONKS_LOCK = threading.RLock()
_STONKS_LOCK_DEPTH = threading.local()

@contextmanager
def _stonks_transaction():
    with _STONKS_LOCK:
        depth = getattr(_STONKS_LOCK_DEPTH, 'value', 0)
        _STONKS_LOCK_DEPTH.value = depth + 1
        try:
            if depth or os.name == 'nt':
                yield
            else:
                import fcntl
                with open(_STONKS_DIR / 'state.lock', 'a+') as lock:
                    fcntl.flock(lock, fcntl.LOCK_EX)
                    try:
                        yield
                    finally:
                        fcntl.flock(lock, fcntl.LOCK_UN)
        finally:
            _STONKS_LOCK_DEPTH.value = depth


def _stonks_serialized(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        with _stonks_transaction():
            return fn(*args, **kwargs)
    return wrapped


def _stonks_atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with open(temp, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
        if os.name != 'nt':
            fd = os.open(str(path.parent), os.O_RDONLY)
            try: os.fsync(fd)
            finally: os.close(fd)
    finally:
        if temp.exists(): temp.unlink()


'''+s[pos:]
s=s.replace("'pending_entries': {},", "'pending_entries': {},\n        'position_ledger': {},")
start=s.index('def _stonks_read():');end=s.index('\ndef _stonks_audit_file',start)
s=s[:start]+'''def _stonks_read():
    p = _stonks_file()
    if not p.exists():
        return _stonks_default()
    # Corrupt state must fail closed, never silently lose ownership/kill switches.
    d = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(d, dict):
        raise RuntimeError('Estado Stonks no válido; ejecución bloqueada')
    base = _stonks_default()
    base.update(d)
    return base


def _stonks_write(d):
    _stonks_atomic_json(_stonks_file(), d)

'''+s[end:]
s=s.replace("p.write_text(json.dumps({'scope_id':str(scope_id),'updated_at':datetime.now(timezone.utc).isoformat()},ensure_ascii=False,indent=2),encoding='utf-8')", "_stonks_atomic_json(p, {'scope_id':str(scope_id),'updated_at':datetime.now(timezone.utc).isoformat()})")
start=s.index('def _stonks_reconcile_paper_state');end=s.index('\ndef _stonks_audit_append',start)
s=s[:start]+'''def _stonks_order_history(after):
    """Complete history since the oldest active intent; fail closed on truncation."""
    rows = []
    params = {'status': 'all', 'limit': 500, 'direction': 'desc', 'nested': 'false', 'after': after}
    for _ in range(100):
        page = _alpaca_paper_request('/v2/orders', params=dict(params))
        if not isinstance(page, list):
            raise RuntimeError('Historial Paper no válido')
        rows.extend(page)
        if len(page) < 500:
            return rows
        # Timestamp pagination can lose orders sharing a boundary timestamp.
        boundary = page[-1].get('submitted_at')
        if not boundary or boundary == params.get('until') or sum(o.get('submitted_at') == boundary for o in page) > 1:
            raise RuntimeError('Historial Paper ambiguo o truncado; ejecución bloqueada')
        params['until'] = boundary
    raise RuntimeError('Historial Paper demasiado largo; ejecución bloqueada')


def _stonks_reconcile_paper_state(scope_id, symbols=None, emit_audit=True):
    # Never filter ownership by the current watchlist: removed symbols still need protection.
    positions = _alpaca_paper_request('/v2/positions')
    orders = _alpaca_paper_request('/v2/orders', params={'status':'open','limit':500,'nested':'false'})
    if not isinstance(positions, list) or not isinstance(orders, list) or len(orders) >= 500:
        raise RuntimeError('Snapshot Paper incompleto; ejecución bloqueada')
    d = _stonks_read()
    active = stonks_lifecycle.active_records(d)
    history = _stonks_order_history(min(r['submitted_at'] for r in active)) if active else []
    d['engine_last_positions'] = positions
    d['engine_last_open_orders'] = orders
    d['engine_last_reconcile'] = datetime.now(timezone.utc).isoformat()
    signature = json.dumps({'positions':positions, 'orders':orders}, sort_keys=True)
    changed = signature != d.get('engine_last_state_signature')
    d['engine_last_state_signature'] = signature
    _stonks_write(d)
    if emit_audit and changed:
        _stonks_audit_append('RECONCILIACIÓN PAPER', {'position_count':len(positions), 'open_order_count':len(orders)})
    return {'positions':positions, 'open_orders':orders, 'history':history, 'changed':changed}


def _stonks_lookup_order(cid):
    return _alpaca_paper_request('/v2/orders:by_client_order_id', params={'client_order_id':cid}, missing_ok=True)


def _stonks_submit_paper_order(body):
    # Fixed Paper URL + Paper-only credential names; caller holds the state transaction.
    key, secret = _alpaca_paper_credentials()
    if not key or not secret:
        raise RuntimeError('Credenciales Paper no configuradas')
    response = requests.post('https://paper-api.alpaca.markets/v2/orders',
        headers={'APCA-API-KEY-ID':key, 'APCA-API-SECRET-KEY':secret}, json=body, timeout=12)
    if not response.ok:
        raise RuntimeError('Orden Paper no confirmada; reconciliar identificador antes de reintentar')
    order = response.json()
    if not isinstance(order, dict) or not order.get('id'):
        raise RuntimeError('Respuesta Paper no válida')
    return order


def _stonks_manage_positions(scope_id, recon, clock=None):
    d = _stonks_read()
    # Old releases did not prove a flat baseline before submitting. Never adopt ambiguous lots.
    for symbol, row in d.get('managed_positions', {}).items():
        if not row.get('client_order_id'):
            reason = 'Ownership anterior a 31.3.20 sin baseline verificable; revisión manual requerida'
            if row.get('reason') != reason:
                _stonks_audit_append('POSITION_ERROR', {'symbol':symbol, 'reason':reason})
            row.update(symbol=symbol, status='ERROR', reason=reason)
    for symbol, meta in d.get('pending_entries', {}).items():
        if symbol not in d['managed_positions']:
            d['managed_positions'][symbol] = {**meta, 'symbol':symbol, 'status':'ERROR',
                'reason':'Entrada antigua sin baseline verificable; revisión manual requerida'}
    return stonks_lifecycle.manage(d, recon['positions'], recon['history'] + recon['open_orders'],
        _stonks_lookup_order, _stonks_submit_paper_order, _stonks_write, _stonks_audit_append,
        lambda: _alpaca_paper_request('/v2/account'), clock or {'is_open':False})

'''+s[end:]
s=s.replace("p=_stonks_audit_file(); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')", "_stonks_atomic_json(_stonks_audit_file(), rows)")
s=s.replace("def _alpaca_paper_request(path, method='GET', params=None):", "def _alpaca_paper_request(path, method='GET', params=None, missing_ok=False):")
s=s.replace("    try: data=r.json()\n    except Exception: data={'raw':r.text[:1000]}\n    if not r.ok:\n        msg=data.get('message') if isinstance(data,dict) else None\n        raise RuntimeError(f'Alpaca Paper {r.status_code}: {msg or \"respuesta no válida\"}')", "    if missing_ok and r.status_code == 404:\n        return None\n    try: data=r.json()\n    except Exception: data={}\n    if not r.ok:\n        raise RuntimeError(f'Alpaca Paper HTTP {r.status_code}; consulta no confirmada')")
s=s.replace('def _stonks_engine_cycle(scope_id):', '@_stonks_serialized\ndef _stonks_engine_cycle(scope_id):')
s=s.replace("        if not d.get('autonomous_engine') or d.get('revoked') or d.get('paused') or d.get('execution_mode')!='paper_auto' or d.get('mode')!='paper':\n            return {'status':'idle','reason':'Motor autónomo desactivado, pausado, revocado o fuera de Paper.'}\n", '')
start=s.index("            clock=_alpaca_paper_request('/v2/clock')",s.index('def _stonks_engine_cycle'));end=s.index('            for symbol in symbols[:8]:',start)
s=s[:start]+'''            recon = _stonks_reconcile_paper_state(scope_id, emit_audit=True)
            clock = _alpaca_paper_request('/v2/clock')
            lifecycle = _stonks_manage_positions(scope_id, recon, clock)
            d = _stonks_read()
            reason = stonks_lifecycle.blocked({**d, 'position_lifecycle_enabled':True}, clock)
            if reason:
                d['engine_last_run'] = datetime.now(timezone.utc).isoformat()
                d['engine_last_action'] = reason
                _stonks_write(d)
                return {'status':'idle', 'reason':reason}
            open_symbols = {o['symbol'] for o in recon['open_orders']}
            open_symbols.update(p['symbol'] for p in recon['positions'])
            open_symbols.update(r['symbol'] for r in stonks_lifecycle.active_records(d))
            actions = list(lifecycle.get('actions') or [])
'''+s[end:]
s=s.replace('result=stonks_decision_api()', 'result=stonks_decision_api(engine=True)')
s=s.replace('_stonks_manage_positions(scope_id, recon2)', '_stonks_manage_positions(scope_id, recon2, clock)')
s=s.replace("d['engine_last_action']=f'ERROR · {exc}'", "d['engine_last_action']='ERROR · reconciliación Paper no disponible; sin órdenes'")
s=s.replace("_stonks_audit_append('MOTOR AUTÓNOMO',{'decision':'ERROR','error':str(exc)})\n            return {'status':'error','reason':str(exc)}", """for row in d.get('managed_positions', {}).values():
                if row.get('status') != 'CERRADA':
                    row.update(status='ERROR', reason='Snapshot Paper no disponible; conservando último estado')
            _stonks_write(d)
            _stonks_audit_append('POSITION_ERROR', {'reason':'Reconciliación Paper no disponible; sin órdenes'})
            return {'status':'error','reason':'Reconciliación Paper no disponible'}""")
# An observation owner survives revoke/disable, so one existing worker keeps reconciling.
s=s.replace("    if _stonks_engine_owner_read()==_user_scope_id(): _stonks_engine_owner_write('')", "    # Retain owner for read-only reconciliation while disabled/revoked.")
s=s.replace('def stonks_decision_api():', 'def stonks_decision_api(engine=False):')
needle="        current=next((p for p in positions if str(p.get('symbol','')).upper()==symbol),None)"
pos=s.index(needle,s.index('def stonks_decision_api'))+len(needle)
s=s[:pos]+'''
        if engine:
            add_check('ENGINE_OWNER', 'Motor no autorizado', d.get('autonomous_engine') and _stonks_engine_owner_read()==_user_scope_id())
            add_check('FLAT_BASELINE', 'El motor solo abre símbolos sin posición previa', current is None)
            add_check('OWNERSHIP_PENDING', 'Hay una intención ZAR pendiente de reconciliar',
                      not any(r['symbol']==symbol for r in stonks_lifecycle.active_records(d)))
'''+s[pos:]
pos=s.index("            key_api,secret_api=_alpaca_paper_credentials()",s.index('def stonks_decision_api'))
s=s[:pos]+'''            if engine:
                intent = stonks_lifecycle.entry_intent(d, symbol, body['side'], qty, strategy, timeframe)
                body['client_order_id'] = intent['client_order_id']
                d['last_executed_signals'][key] = datetime.now(timezone.utc).isoformat()
                _stonks_write(d)  # ownership + dedup intent durable BEFORE network
                order = _stonks_submit_paper_order(body)
                intent['order_id'] = order['id']
                _stonks_write(d)
                result.update(order_created=True, order=order)
                _stonks_audit_append('ORDEN PAPER', {'symbol':symbol, 'qty':qty, 'price':price,
                    'order_id':order['id'], 'client_order_id':intent['client_order_id'], 'strategy':strategy})
                return jsonify(result)
'''+s[pos:]
start=s.index("                if requested_signal=='BUY' and d.get('position_lifecycle_enabled')",s.index('def stonks_decision_api'));end=s.index("                d['execution_mode']",start)
s=s[:start]+s[end:]
# Serialize ALL Stonks route operations as well as the worker. Wrap under @app.route.
import re
s=re.sub(r'(?m)^def (stonks_\w+_api)\(',r'@_stonks_serialized\ndef \1(',s)
p.write_text(s,encoding='utf-8')
