from pathlib import Path
p=Path('tests/test_stonks_lifecycle.py');s=p.read_text(encoding='utf-8-sig')
pos=s.index("\n\nif __name__=='__main__'")
s=s[:pos]+'''
    def configure_worker(self, signal='BUY'):
        self.save(self.state)
        self.api['_stonks_engine_owner_write']('test-owner')
        self.api['_stonks_current_signal'] = Mock(return_value=({'signal':signal,'bar_time':'2026-09-28T10:00:00Z'},self.clock))
        self.api['_alpaca_market_request'] = Mock(return_value={'trade':{'p':100}})
        def broker(path, **kwargs):
            if path=='/v2/positions':return self.positions
            if path=='/v2/clock':return self.clock
            if path=='/v2/account':return self.account
            if path=='/v2/orders:by_client_order_id':return self.orders.get(kwargs['params']['client_order_id'])
            if path=='/v2/orders':
                return [o for o in self.orders.values() if kwargs['params']['status']=='all' or o['status'] not in lifecycle.TERMINAL]
            raise AssertionError(path)
        self.api['_alpaca_paper_request'] = Mock(side_effect=broker)
        def submit(body):
            disk=self.api['_stonks_read']()
            if body['client_order_id'].startswith('zar-e-'):
                self.assertIn(body['client_order_id'],disk['position_ledger'])
                self.assertTrue(disk['last_executed_signals'])
            self.posts.append(copy.deepcopy(body))
            order=dict(body,id='order-'+str(len(self.posts)),status='new',filled_qty='0',submitted_at=lifecycle.now())
            self.orders[body['client_order_id']]=order
            return order
        self.api['_stonks_submit_paper_order']=Mock(side_effect=submit)

    def test_worker_entry_persisted_before_post_and_recovered_after_timeout(self):
        self.configure_worker()
        submit=self.api['_stonks_submit_paper_order'].side_effect
        def uncertain(body):
            submit(body)
            raise TimeoutError()
        self.api['_stonks_submit_paper_order'].side_effect=uncertain
        self.api['_stonks_engine_cycle']('test-owner')
        self.assertEqual(len(self.posts),1)
        self.assertEqual(self.api['_stonks_read']()['managed_positions'],{})
        order=self.orders[self.posts[0]['client_order_id']]
        order.update(status='filled',filled_qty=order['qty'],filled_at=lifecycle.now())
        self.position(qty=order['qty'])
        self.api['_stonks_submit_paper_order'].side_effect=submit
        self.api['_stonks_engine_cycle']('test-owner')
        self.assertEqual(len(self.posts),1)
        self.assertEqual(self.api['_stonks_read']()['managed_positions']['AAPL']['status'],'PROTEGIDA')

    def test_worker_preserves_owned_strategy_sell_when_sl_tp_disabled(self):
        self.entry()
        self.state['position_lifecycle_enabled']=False
        self.configure_worker(signal='SELL')
        self.api['_stonks_engine_cycle']('test-owner')
        self.assertEqual(len(self.posts),1)
        self.assertEqual(self.posts[0]['side'],'sell')
        self.assertEqual(self.api['_stonks_read']()['managed_positions']['AAPL']['status'],'CERRANDO_SIGNAL')

    def test_worker_does_not_trade_manual_position(self):
        self.position()
        self.configure_worker(signal='SELL')
        self.api['_stonks_engine_cycle']('test-owner')
        self.assertEqual(self.posts,[])

    def test_worker_overlapping_cycles_send_only_one_entry(self):
        self.configure_worker()
        results=[]
        threads=[threading.Thread(target=lambda:results.append(self.api['_stonks_engine_cycle']('test-owner'))) for _ in range(3)]
        for thread in threads:thread.start()
        for thread in threads:thread.join(timeout=5)
        self.assertEqual(len(results),3)
        self.assertEqual(len(self.posts),1)

    def test_revoke_preserves_owner_and_restart_observation(self):
        self.entry();self.configure_worker()
        self.api['stonks_revoke_api']()
        self.assertEqual(self.api['_stonks_engine_owner_read'](),'test-owner')
        self.api['_stonks_engine_cycle']('test-owner')
        self.assertEqual(self.posts,[])
        self.assertEqual(self.api['_stonks_read']()['managed_positions']['AAPL']['status'],'ABIERTA')

    def test_history_id_cursor_handles_equal_timestamps(self):
        page=[{'id':str(i),'submitted_at':'2026-09-28T10:00:00Z'} for i in range(500)]
        broker=Mock(side_effect=[page,[{'id':'older','submitted_at':'2026-09-28T09:00:00Z'}]])
        self.api['_alpaca_paper_request']=broker
        rows=self.api['_stonks_order_history']('2026-09-27T00:00:00Z')
        self.assertEqual(len(rows),501)
        params=broker.call_args_list[1].kwargs['params']
        self.assertEqual(params['before_order_id'],'499')
        self.assertNotIn('after',params)

    def test_history_repeated_page_fails_closed(self):
        page=[{'id':str(i),'submitted_at':'2026-09-28T10:00:00Z'} for i in range(500)]
        self.api['_alpaca_paper_request']=Mock(return_value=page)
        with self.assertRaises(RuntimeError):self.api['_stonks_order_history']('2026-09-27T00:00:00Z')

    def test_partial_close_updates_remaining_without_duplicate(self):
        self.entry(price=98);self.cycle()
        order=self.orders[self.posts[0]['client_order_id']]
        order.update(status='partially_filled',filled_qty='1')
        self.position(qty='1',price=98)
        self.cycle()
        self.assertEqual(len(self.posts),1)
        self.assertEqual(self.row()['qty'],'1.0')

    def test_rejected_close_does_not_resubmit(self):
        self.entry(price=98);self.cycle()
        self.orders[self.posts[0]['client_order_id']]['status']='rejected'
        self.cycle();self.cycle()
        self.assertEqual(len(self.posts),1)
        self.assertEqual(self.row()['status'],'ERROR')

    def test_missing_owned_symbol_from_watchlist_still_managed(self):
        self.entry(price=98)
        self.state['engine_symbols']=['MSFT']
        self.configure_worker(signal='HOLD')
        self.api['_stonks_engine_cycle']('test-owner')
        self.assertEqual(self.posts[0]['symbol'],'AAPL')

    def test_old_ambiguous_ownership_never_adopted(self):
        self.state['managed_positions']={'AAPL':{'entry_price':100,'qty':'2'}}
        self.position(price=98);self.save(self.state)
        self.api['_stonks_submit_paper_order']=Mock()
        self.api['_stonks_manage_positions']('test-owner',{'positions':self.positions,'open_orders':[],'history':[]},self.clock)
        self.api['_stonks_submit_paper_order'].assert_not_called()
        self.assertEqual(self.api['_stonks_read']()['managed_positions']['AAPL']['status'],'ERROR')
'''+s[pos:]
p.write_text(s,encoding='utf-8')
