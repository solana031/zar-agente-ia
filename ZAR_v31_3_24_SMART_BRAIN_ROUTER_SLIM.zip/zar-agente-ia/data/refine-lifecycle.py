from pathlib import Path
p=Path('app/main.py');s=p.read_text(encoding='utf-8')
for name in ['stonks_status_api','stonks_audit_api','stonks_alpaca_quote_api','stonks_signals_api','stonks_backtest_api','stonks_alpaca_portfolio_api','stonks_alpaca_positions_api','stonks_alpaca_position_get_api','stonks_alpaca_orders_api','stonks_alpaca_order_get_api']:
 s=s.replace('@_stonks_serialized\ndef '+name,'def '+name)
start=s.index('def _stonks_order_history(');end=s.index('\n\ndef _stonks_reconcile_paper_state',start)
s=s[:start]+'''def _stonks_order_history(after):
    """ID cursor pagination avoids losing fills at equal submission timestamps."""
    rows, seen = [], set()
    cutoff = stonks_lifecycle.timestamp(after)
    params = {'status':'all', 'limit':500, 'direction':'desc', 'nested':'false', 'after':after}
    for _ in range(100):
        page = _alpaca_paper_request('/v2/orders', params=dict(params))
        if not isinstance(page, list):
            raise RuntimeError('Historial Paper no válido')
        if any(not o.get('id') or o['id'] in seen for o in page):
            raise RuntimeError('Historial Paper repetido/incompleto; ejecución bloqueada')
        rows.extend(page)
        seen.update(o['id'] for o in page)
        if len(page) < 500 or stonks_lifecycle.timestamp(page[-1]['submitted_at']) <= cutoff:
            return rows
        params.pop('after', None)
        params['before_order_id'] = page[-1]['id']
    raise RuntimeError('Historial Paper demasiado largo; ejecución bloqueada')
'''+s[end:]
s=s.replace("history = _stonks_order_history(min(r['submitted_at'] for r in active)) if active else []", "history = _stonks_order_history(stonks_lifecycle.history_start(active)) if active else []")
s=s.replace("            open_symbols.update(p['symbol'] for p in recon['positions'])\n            open_symbols.update(r['symbol'] for r in stonks_lifecycle.active_records(d))", """            held_symbols = {p['symbol'] for p in recon['positions']}
            records = {r['symbol']:r for r in stonks_lifecycle.active_records(d)}
            open_symbols.update(symbol for symbol in records if symbol not in held_symbols)""")
s=s.replace("                    signal, _ = _stonks_current_signal(symbol,strategy,timeframe,'iex')", """                    if symbol in held_symbols and symbol not in records:
                        actions.append(symbol + ': posición manual; sin gestión automática')
                        continue
                    signal, _ = _stonks_current_signal(symbol,strategy,timeframe,'iex')
                    if symbol in held_symbols:
                        # Preserve strategy SELL exits for owned LONGs, through the same
                        # durable close/Risk state machine (also when SL/TP is disabled).
                        record = records[symbol]
                        if signal.get('signal') == 'SELL' and record['side'] == 'buy':
                            latest = _stonks_read()
                            owned = latest['position_ledger'][record['client_order_id']]
                            if not owned.get('trigger'):
                                owned['trigger'] = 'SIGNAL'
                                _stonks_write(latest)
                                _stonks_audit_append('SIGNAL_TRIGGERED', {'symbol':symbol, 'reason':'Salida por estrategia'})
                            result = _stonks_manage_positions(scope_id, _stonks_reconcile_paper_state(scope_id), clock)
                            actions.extend(result.get('actions') or [])
                        continue""")
p.write_text(s,encoding='utf-8')
p=Path('app/stonks_lifecycle.py');s=p.read_text(encoding='utf-8')
s=s.replace('from datetime import datetime, timezone','from datetime import datetime, timezone, timedelta')
pos=s.index('\ndef entry_intent(')
s=s[:pos]+'''
def timestamp(value):
    return datetime.fromisoformat(str(value).replace('Z', '+00:00'))


def history_start(records):
    # Include a clock-skew margin; actual ownership boundaries use broker timestamps.
    return (min(timestamp(r['submitted_at']) for r in records) - timedelta(days=1)).isoformat()

'''+s[pos:]
s=s.replace("and str(o.get('submitted_at') or '') >= record['submitted_at']\n                       and (number", "and (o.get('status') not in TERMINAL or timestamp(o['submitted_at']) >= timestamp(entry['submitted_at']))\n                       and (number")
s=s.replace("            reason = blocked(state, clock)", "            reason = blocked({**state, 'position_lifecycle_enabled':True} if record.get('trigger')=='SIGNAL' else state, clock)")
s=s.replace("                if reason or not (stop or take):", "                if reason or (not (stop or take) and not record.get('trigger')):")
p.write_text(s,encoding='utf-8')
