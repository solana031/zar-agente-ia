from pathlib import Path
p=Path('app/stonks_lifecycle.py');s=p.read_text(encoding='utf-8-sig')
s=s.replace('account, clock):','account, clock, cancel=None):')
s=s.replace("                error(row, 'Entrada parcial todavía abierta: SL/TP pendiente hasta fin/cancelación de entrada')\n                continue", """                row.update(status='ABIERTA', reason='SL/TP alcanzado: cancelando remanente de entrada antes de cerrar')
                save(state)
                if cancel and entry.get('status') != 'pending_cancel':
                    cancel(entry['id'])
                continue""")
p.write_text(s,encoding='utf-8')
p=Path('app/main.py');s=p.read_text(encoding='utf-8')
s=s.replace("lambda: _alpaca_paper_request('/v2/account'), clock or {'is_open':False})", "lambda: _alpaca_paper_request('/v2/account'), clock or {'is_open':False},\n        cancel=lambda order_id: _alpaca_paper_request('/v2/orders/'+order_id, method='DELETE'))")
s=s.replace("fcntl.flock(fh,fcntl.LOCK_EX|fcntl.LOCK_NB)","fcntl.flock(fh,fcntl.LOCK_EX)")
s=s.replace("            open_symbols.update(r['symbol'] for r in stonks_lifecycle.active_records(d))", "            open_symbols.update(r['symbol'] for r in stonks_lifecycle.active_records(d))\n            open_symbols.update(d.get('pending_entries', {}))")
s=s.replace("'managed_position_count':len(d.get('managed_positions') or {})", "'managed_position_count':sum(r.get('status')!='CERRADA' for r in (d.get('managed_positions') or {}).values())")
p.write_text(s,encoding='utf-8')
p=Path('app/templates/index.html');s=p.read_text(encoding='utf-8')
needle='<div id="zsLifecycleMeta" class="zsInfo" style="margin-top:9px">Sin posiciones ZAR gestionadas.</div>'
assert s.count(needle)==1
s=s.replace(needle,needle+'''<div class="zsInfo" style="margin-top:9px">SL/TP evaluado en servidor cada ~5 s, solo Paper. Pausa, Revocación, motor desactivado o límites Risk suspenden nuevos cierres; la reconciliación continúa. Las órdenes ya aceptadas pueden ejecutarse. PROTEGIDA indica vigilancia del servidor, no una orden stop alojada en Alpaca.</div><div class="zsPortfolioTableWrap"><table class="zsTable"><thead><tr><th>Símbolo</th><th>Dirección</th><th>Cantidad</th><th>Entrada USD</th><th>Actual USD</th><th>Valor USD</th><th>P/L USD</th><th>P/L %</th><th>SL USD</th><th>TP USD</th><th>Dist. SL %</th><th>Dist. TP %</th><th>Apertura</th><th>Estrategia / origen</th><th>Estado</th></tr></thead><tbody id="zsManagedPositionsBody"><tr data-empty="1"><td colspan="15">Sin posiciones ZAR detectadas.</td></tr></tbody></table></div>''')
pos=s.index('async function zsRefreshStatus()')
s=s[:pos]+'''function zsRenderManagedPositions(positions){
  const body=document.getElementById('zsManagedPositionsBody');if(!body)return;
  const rows=Object.values(positions||{}).sort((a,b)=>String(a.symbol).localeCompare(String(b.symbol)));
  const present=new Set();
  const fmt=v=>v==null?'—':Number(v).toLocaleString('es-ES',{maximumFractionDigits:4});
  if(rows.length)body.querySelector('[data-empty]')?.remove();
  for(const p of rows){
    const key=p.client_order_id||p.symbol;present.add(key);
    let row=Array.from(body.rows).find(r=>r.dataset.positionKey===key);
    if(!row){row=document.createElement('tr');row.dataset.positionKey=key;for(let i=0;i<15;i++)row.appendChild(document.createElement('td'));body.appendChild(row)}
    const values=[p.symbol,p.direction||'—',p.qty||'—',fmt(p.entry_price),fmt(p.current_price),fmt(p.market_value),fmt(p.unrealized_pl),fmt(p.unrealized_pl_pct),fmt(p.stop_price),fmt(p.take_price),fmt(p.distance_sl_pct),fmt(p.distance_tp_pct),p.opened_at?zsSignalTime(p.opened_at):'—',[p.strategy,p.origin].filter(Boolean).join(' / ')||'—',[p.status,p.reason].filter(Boolean).join(' · ')];
    values.forEach((value,i)=>{const text=String(value);if(row.cells[i].textContent!==text)row.cells[i].textContent=text});
  }
  for(const row of Array.from(body.rows)){if(row.dataset.positionKey&&!present.has(row.dataset.positionKey))row.remove()}
  if(!rows.length&&!body.querySelector('[data-empty]')){const row=body.insertRow();row.dataset.empty='1';const cell=row.insertCell();cell.colSpan=15;cell.textContent='Sin posiciones ZAR detectadas.'}
}
'''+s[pos:]
s=s.replace("const paused=!!j.paused;const revoked=!!j.revoked;", "zsRenderManagedPositions(j.managed_positions);const paused=!!j.paused;const revoked=!!j.revoked;")
s=s.replace('v31.3.19','v31.3.20')
p.write_text(s,encoding='utf-8')
for name in ['VERSION','VERSION.txt','app/VERSION.txt']:
 Path(name).write_text('31.3.20\n',encoding='utf-8')
p=Path('tests/stonks-rendering.cjs');s=p.read_text(encoding='utf-8').replace("'31.3.19'","'31.3.20'")
s=s.replace("signals: [], positions: [], orders: [], audit: []", """managed_positions: {AAPL: {symbol:'AAPL', client_order_id:'zar-e-test', direction:'LONG', qty:'2', entry_price:100, current_price:101, market_value:202, unrealized_pl:2, unrealized_pl_pct:1, stop_price:98.5, take_price:103, distance_sl_pct:2.4752, distance_tp_pct:1.9802, opened_at:'2026-09-28T10:00:00Z', strategy:'trend', origin:'motor autónomo', status:'PROTEGIDA'}},
          signals: [], positions: [], orders: [], audit: []""")
s=s.replace("await checkLayout();\n      assert.equal(await page.locator('#stonksStopLoss')", """await checkLayout();
      assert.equal(await page.locator('#zsManagedPositionsBody tr').count(), 1);
      assert.match(await page.locator('#zsManagedPositionsBody').textContent(), /AAPL.*LONG.*PROTEGIDA/);
      const stable = await page.evaluate(async () => {
        const row=document.querySelector('#zsManagedPositionsBody tr');
        await zsRefreshStatus();
        return row===document.querySelector('#zsManagedPositionsBody tr');
      });
      assert.equal(stable,true,'Sync must update cells without replacing rows or reloading');
      for(const status of ['ABIERTA','CERRANDO_SL','CERRANDO_TP','CERRADA','ERROR']){
        await page.evaluate(status=>zsRenderManagedPositions({AAPL:{symbol:'AAPL',direction:'SHORT',client_order_id:'zar-e-test',status,strategy:'<script>bad</script>'}}),status);
        assert.match(await page.locator('#zsManagedPositionsBody').textContent(),new RegExp(status));
        assert.equal(await page.locator('#zsManagedPositionsBody script').count(),0);
      }
      await page.evaluate(()=>zsRefreshStatus());
      assert.equal(await page.locator('#stonksStopLoss')""")
p.write_text(s,encoding='utf-8')
