from pathlib import Path
p=Path('tests/stonks-rendering.cjs');s=p.read_text(encoding='utf-8')
s=s.replace("        if (url.pathname === '/static/skills.js')", "        if (url.pathname === '/static/zar-silhouette.png') return route.fulfill({contentType:'image/png',body:fs.readFileSync('app/static/zar-silhouette.png')});\n        if (url.pathname === '/static/skills.js')")
s=s.replace("        const wrap=page.locator('#zsManagedPositionsBody').locator('xpath=../..');", "        await page.locator('#zsManagedPositionsBody td').last().evaluate(e=>{e.textContent='TEST_LIFECYCLE_'.repeat(15);e.style.whiteSpace='nowrap'});\n        const wrap=page.locator('#zsManagedPositionsBody').locator('xpath=../..');")
s=s.replace("        await checkResponsive();\n      }\n      assert.match", "        await checkResponsive();\n        await page.evaluate(()=>zsRefreshStatus());\n      }\n      assert.match")
p.write_text(s,encoding='utf-8')
