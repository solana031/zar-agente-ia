from pathlib import Path
p=Path('app/templates/index.html');s=p.read_text(encoding='utf-8')
s=s.replace('<ol id="zsLifecycleTestSteps"></ol>', '<ol id="zsLifecycleTestSteps"></ol><div id="zsPaperPreflight" aria-live="polite">⚠ ESTADO NO VERIFICADO</div><button id="zsPreflightRefresh" class="zsBtn" onclick="zsRefreshPreflight()">Volver a comprobar</button>')
s=s.replace('id="zsLifecycleTestSymbol" value="AAPL"', 'id="zsLifecycleTestSymbol" oninput="zsInvalidatePreflight()" value="AAPL"')
marker='let zsLifecycleTestState=null, zsLifecycleTestBusy=false, zsLifecycleTestRequestId=null;'
js='''let zsPreflight=null, zsPreflightPending=null;
function zsInvalidatePreflight(){zsPreflight=null;zsRenderPreflight();zsRenderLifecycleTest(zsLifecycleTestState||{})}
function zsRenderPreflight(){
  const box=document.getElementById('zsPaperPreflight');if(!box)return;
  const p=zsPreflight,labels={READY:'🟢 LISTO PARA PRUEBA PAPER',BLOCKED:'🔴 PRUEBA BLOQUEADA',UNVERIFIED:'🟠 ESTADO NO VERIFICADO'};
  box.replaceChildren();
  const title=document.createElement('strong');title.textContent=labels[p?.status]||labels.UNVERIFIED;box.append(title);
  const meta=document.createElement('p');meta.textContent=p?'Última comprobación: '+new Date(p.checked_at).toLocaleString()+' · Mercado: '+(p.market_open===true?'abierto':p.market_open===false?'cerrado':'no verificado')+(p.next_open?' · Próxima apertura: '+p.next_open:''):'Pendiente de comprobación del servidor';box.append(meta);
  for(const check of p?.checks||[]){const line=document.createElement('div');line.textContent=({PASS:'✅ Correcto',BLOCKED:'❌ Bloqueado',UNVERIFIED:'⚠ No verificado'}[check.status]||'⚠ No verificado')+' · '+check.label;box.append(line)}
}
async function zsRefreshPreflight(){
  if(zsPreflightPending)return zsPreflightPending;
  const symbol=document.getElementById('zsLifecycleTestSymbol')?.value.trim().toUpperCase();if(!symbol)return zsInvalidatePreflight();
  const button=document.getElementById('zsPreflightRefresh');if(button)button.disabled=true;
  zsPreflightPending=(async()=>{
    try{
      const response=await fetch('/api/stonks/lifecycle-test/preflight?symbol='+encodeURIComponent(symbol),{cache:'no-store'});
      const result=await response.json();
      if(!response.ok||!result.ok)throw new Error('Pre-flight no disponible');
      if(document.getElementById('zsLifecycleTestSymbol')?.value.trim().toUpperCase()===symbol)zsPreflight=result.preflight;
    }catch(e){zsPreflight=null}
    finally{zsPreflightPending=null;if(button)button.disabled=false;zsRenderPreflight();zsRenderLifecycleTest(zsLifecycleTestState||{})}
  })();return zsPreflightPending;
}
'''
assert marker in s;s=s.replace(marker,js+marker)
s=s.replace("if(start)start.disabled=zsLifecycleTestBusy||!ready||!!t.active;", "if(start)start.disabled=zsLifecycleTestBusy||!ready||!!t.active||zsPreflight?.status!=='READY'||zsPreflight?.symbol!==document.getElementById('zsLifecycleTestSymbol')?.value.trim().toUpperCase()||!(Date.now()-Date.parse(zsPreflight?.checked_at)<15000);")
s=s.replace('zsRenderManagedPositions(j.managed_positions);zsRenderLifecycleTest(j);', 'zsRenderManagedPositions(j.managed_positions);zsLifecycleTestState=j;await zsRefreshPreflight();zsRenderLifecycleTest(j);')
s=s.replace("  bodyEl.classList.add('stonks-host');", "  zsPreflight=null;\n  bodyEl.classList.add('stonks-host');")
p.write_text(s,encoding='utf-8')
