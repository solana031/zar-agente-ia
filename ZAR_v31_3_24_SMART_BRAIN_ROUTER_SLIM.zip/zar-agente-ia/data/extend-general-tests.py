from pathlib import Path
p=Path('tests/general-ui.cjs');s=p.read_text(encoding='utf-8')
s=s.replace(" await page.locator('.editorModeTab').filter({hasText:'AUDIO'}).click();await globalWidth();", " await page.locator('.editorModeTab').filter({hasText:'AUDIO'}).click();await globalWidth();\n await page.evaluate(()=>renderAudioEditor({id:'mock-audio',name:'Prueba audio',instruments:['kick','bass'],tracks:[],bpm:120,duration:30}));await globalWidth();await bounds('.zarAudioPro',false);")
s=s.replace(" await page.setViewportSize({width,height});", """ await page.setViewportSize({width,height});
 // Simulate a visual viewport reduced by a keyboard without resizing layout viewport.
 await page.evaluate(()=>{Object.defineProperty(visualViewport,'height',{configurable:true,value:350});visualViewport.dispatchEvent(new Event('resize'))});
 const composerBottom=await page.locator('.composerMain').evaluate(e=>e.getBoundingClientRect().bottom);
 assert.ok(composerBottom<=350,`keyboard composer bottom ${composerBottom}`);
 await page.evaluate(()=>{delete visualViewport.height;visualViewport.dispatchEvent(new Event('resize'))});""")
p.write_text(s,encoding='utf-8')
