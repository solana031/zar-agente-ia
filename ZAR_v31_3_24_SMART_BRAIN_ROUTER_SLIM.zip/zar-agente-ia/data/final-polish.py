from pathlib import Path
p=Path('tests/general-ui.cjs');s=p.read_text(encoding='utf-8');s=s.replace(" assert.ok((await page.locator('#mediaWorkspace').boundingBox()).width>width*.5,'Studio should use available width');", """ assert.ok((await page.locator('#mediaWorkspace').boundingBox()).width>width*.5,'Studio should use available width');
 await page.evaluate(()=>showStudioTime());await page.locator('[data-close-context]').click();
 assert.equal(await page.locator('#studioContextPopup').isVisible(),false);""");p.write_text(s,encoding='utf-8')
p=Path('app/static/ui-polish.js');p.write_text(p.read_text(encoding='utf-8-sig').rstrip()+'\n',encoding='utf-8')
