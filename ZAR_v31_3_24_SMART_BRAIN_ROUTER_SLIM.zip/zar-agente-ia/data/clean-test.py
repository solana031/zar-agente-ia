from pathlib import Path
p=Path('tests/general-ui.cjs');s=p.read_text(encoding='utf-8-sig');s=s.replace('console.log("CHECK",width,theme,fn);','');p.write_text(s.rstrip()+'\n',encoding='utf-8')
