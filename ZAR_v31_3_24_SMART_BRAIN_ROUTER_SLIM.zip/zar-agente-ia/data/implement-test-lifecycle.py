from pathlib import Path
p=Path('app/stonks_lifecycle.py');s=p.read_text(encoding='utf-8')
pos=s.index('\ndef blocked(')
s=s[:pos]+'''
def test_event(record, name, audit, reason='', qty=None, price=None):
    """Persist test milestones inside the production ledger, without a second state store."""
    if record.get('purpose') != 'TEST_LIFECYCLE':
        return
    events = record.setdefault('test_events', [])
    if name == 'TEST_LIFECYCLE_ERROR':
        if record.get('test_error') == reason:
            return
        record['test_error'] = reason
    elif any(e['event'] == name for e in events):
        return
    events.append({'event':name, 'timestamp':now(), 'reason':reason})
    record['test_events'] = events[-40:]
    audit(name, {'symbol':record['symbol'], 'client_order_id':record['client_order_id'],
                 'qty':qty, 'price':price, 'reason':reason, 'purpose':'TEST_LIFECYCLE'})


def test_view(state):
    records = [r for r in state.get('position_ledger', {}).values() if r.get('purpose')=='TEST_LIFECYCLE']
    if not records:
        return {'active':False, 'status':'SIN_PRUEBA', 'steps':[], 'can_close':False}
    active = [r for r in records if not r.get('closed')]
    record = max(active or records, key=lambda r:r['submitted_at'])
    row = state.get('managed_positions', {}).get(record['symbol'], {})
    if row.get('client_order_id') != record['client_order_id']:
        row = {}
    status = 'ESPERANDO_FILL'
    if record.get('closed'):
        status = 'OK' if any(e['event']=='TEST_LIFECYCLE_OK' for e in record.get('test_events', [])) else 'ERROR'
    elif record.get('test_error'):
        status = 'ERROR'
    elif row.get('opened_at'):
        status = 'CIERRE_SOLICITADO' if record.get('trigger') else 'POSICION_DETECTADA'
        if record.get('exits'):
            status = 'ESPERANDO_CIERRE'
    return {'id':record['client_order_id'], 'purpose':'TEST_LIFECYCLE', 'symbol':record['symbol'],
            'active':not record.get('closed'), 'status':status, 'steps':record.get('test_events', []),
            'error':record.get('test_error'), 'position':row,
            'can_close':bool(row.get('opened_at') and not record.get('closed')
                             and not record.get('trigger') and not record.get('ownership_conflict')
                             and row.get('status')!='ERROR')}

'''+s[pos:]
s=s.replace("        row.update(status='ERROR', reason=reason, updated_at=now())", "        test_event(record, 'TEST_LIFECYCLE_ERROR', audit, reason, row.get('qty'), row.get('current_price'))\n        row.update(status='ERROR', reason=reason, updated_at=now())")
s=s.replace("            filled = number(entry.get('filled_qty') or 0)", """            record.pop('test_error', None)
            test_event(record, 'TEST_ENTRY_REQUESTED', audit, 'Orden confirmada por Alpaca', entry.get('qty'), entry.get('filled_avg_price'))
            filled = number(entry.get('filled_qty') or 0)""")
s=s.replace("                    record['closed'] = True\n                    if managed.get(symbol", "                    test_event(record, 'TEST_LIFECYCLE_ERROR', audit, 'Entrada terminada sin fill: '+str(entry.get('status')))\n                    record['closed'] = True\n                    if managed.get(symbol")
s=s.replace("                record['closed'] = True\n                managed[symbol] = row", """                test_event(record, 'TEST_POSITION_CLOSED', audit, row['reason'], str(filled), row.get('current_price'))
                test_event(record, 'TEST_LIFECYCLE_OK', audit, 'Entrada, ownership y cierre reconciliados en Paper')
                record['closed'] = True
                managed[symbol] = row""")
s=s.replace("                event('POSITION_DETECTED', row, 'Posición y fills reales reconciliados')", "                event('POSITION_DETECTED', row, 'Posición y fills reales reconciliados')\n            test_event(record, 'TEST_POSITION_DETECTED', audit, 'Fill y posición propios verificados', row['qty'], row['entry_price'])")
s=s.replace("                if order:\n                    continue", "                if order:\n                    test_event(record, 'TEST_CLOSE_REQUESTED', audit, intent['trigger'], intent['qty'], row['current_price'])\n                    continue")
s=s.replace("            event('CLOSE_REQUESTED', {**row, 'qty':intent['qty'], 'client_order_id':intent['client_order_id']}, intent['trigger'])", "            event('CLOSE_REQUESTED', {**row, 'qty':intent['qty'], 'client_order_id':intent['client_order_id']}, intent['trigger'])\n            test_event(record, 'TEST_CLOSE_REQUESTED', audit, intent['trigger'], intent['qty'], row['current_price'])")
p.write_text(s,encoding='utf-8')
p=Path('app/main.py');s=p.read_text(encoding='utf-8')
s=s.replace("'position_ledger': {},", "'position_ledger': {},\n        'paper_connected': False,")
# Connection state is verified observationally by the existing worker, never inferred from keys alone.
s=s.replace("    positions = _alpaca_paper_request('/v2/positions')\n    orders =", "    account = _alpaca_paper_request('/v2/account')\n    positions = _alpaca_paper_request('/v2/positions')\n    orders =",1)
s=s.replace("    d['engine_last_positions'] = positions", "    d['paper_connected'] = account.get('status') == 'ACTIVE' and not (account.get('trading_blocked') or account.get('account_blocked'))\n    d['engine_last_positions'] = positions",1)
s=s.replace("                        record = records[symbol]\n                        if signal.get('signal')", "                        record = records[symbol]\n                        if record.get('purpose')=='TEST_LIFECYCLE':\n                            continue\n                        if signal.get('signal')",1)
s=s.replace("            d=_stonks_read(); d['engine_last_run']=datetime.now(timezone.utc).isoformat(); d['engine_last_action']='ERROR · reconciliación Paper no disponible; sin órdenes'; _stonks_write(d)", "            d=_stonks_read(); d['paper_connected']=False; d['engine_last_run']=datetime.now(timezone.utc).isoformat(); d['engine_last_action']='ERROR · reconciliación Paper no disponible; sin órdenes'; _stonks_write(d)\n            for record in stonks_lifecycle.active_records(d):\n                stonks_lifecycle.test_event(record, 'TEST_LIFECYCLE_ERROR', _stonks_audit_append, 'Alpaca no disponible; conservando intención y ownership')")
s=s.replace("'ok':True, **d, 'engine_owner':_stonks_engine_owner_read()", "'ok':True, **d, 'lifecycle_test':stonks_lifecycle.test_view(d), 'engine_owner':_stonks_engine_owner_read()",1)
s=s.replace('def stonks_decision_api(engine=False):', 'def stonks_decision_api(engine=False, lifecycle_test=False):')
s=s.replace("        actual,clock=_stonks_current_signal(symbol,strategy,timeframe,'iex')", """        if lifecycle_test:
            # Internal-only synthetic decision source; every production Risk check below still applies.
            engine = True
            strategy = 'TEST_LIFECYCLE'
            requested_signal = 'BUY'
            execute = True
            actual = {'signal':'BUY', 'bar_time':'TEST:'+str(payload.get('request_id'))}
            clock = _alpaca_paper_request('/v2/clock')
        else:
            actual,clock=_stonks_current_signal(symbol,strategy,timeframe,'iex')""",1)
needle="        add_check('MARKET','Mercado cerrado',bool(clock.get('is_open')))"
s=s.replace(needle,needle+"""
        if lifecycle_test:
            add_check('LIFECYCLE', 'Gestión de posición desactivada', bool(d.get('position_lifecycle_enabled')))
            add_check('AUTO', 'Modo Paper automático requerido', d.get('execution_mode')=='paper_auto')
            add_check('SINGLE_TEST', 'Ya existe una prueba activa', not any(r.get('purpose')=='TEST_LIFECYCLE' for r in stonks_lifecycle.active_records(d)))
""",1)
needle="        equity=float(account.get('equity') or 0); last_equity=float(account.get('last_equity') or 0)"
start=s.index('def stonks_decision_api');idx=s.index(needle,start)+len(needle)
s=s[:idx]+"""
        if lifecycle_test:
            add_check('CONNECTED', 'Alpaca Paper no está disponible para operar', account.get('status')=='ACTIVE' and not (account.get('trading_blocked') or account.get('account_blocked')))
            add_check('BUYING_POWER', 'Saldo Paper insuficiente para 1 USD', float(account.get('buying_power') or 0)>=1)
            asset = _alpaca_paper_request('/v2/assets/'+symbol)
            add_check('FRACTIONABLE', 'Activo no compatible con prueba mínima Paper', asset.get('status')=='active' and asset.get('tradable') is True and asset.get('fractionable') is True and asset.get('class')=='us_equity')
"""+s[idx:]
needle="        order_value=qty*price";idx=s.index(needle,s.index('def stonks_decision_api'))+len(needle)
s=s[:idx]+"""
        if lifecycle_test:
            # Fixed minimal dollar notional avoids quote movement/rounding changing the entry size.
            qty = float(f'{1.0/price:.9f}') if price>0 else 0
            order_value = 1.0
"""+s[idx:]
needle="            if engine:\n                intent = stonks_lifecycle.entry_intent(d, symbol, body['side'], qty, strategy, timeframe)"
s=s.replace(needle,needle+"""
                if lifecycle_test:
                    body.pop('qty')
                    body['notional'] = '1.00'
                    intent.update(purpose='TEST_LIFECYCLE', origin='TEST_LIFECYCLE', test_request_id=payload['request_id'], notional_requested='1.00')
                    stonks_lifecycle.test_event(intent, 'TEST_LIFECYCLE_STARTED', _stonks_audit_append, 'Prueba Paper confirmada; intención persistida', str(qty), price)
""",1)
s=s.replace("                intent['order_id'] = order['id']\n                _stonks_write(d)", "                intent['order_id'] = order['id']\n                if lifecycle_test:\n                    stonks_lifecycle.test_event(intent, 'TEST_ENTRY_REQUESTED', _stonks_audit_append, 'Entrada Paper enviada; esperando fill', str(qty), price)\n                _stonks_write(d)",1)
# Explicit endpoints route through the same decision/ledger and only queue closes for the worker.
pos=s.index("@app.delete('/api/stonks/alpaca/orders')")
s=s[:pos]+'''def _stonks_test_gate(d):
    reason = stonks_lifecycle.blocked(d, {'is_open':True})
    if reason:
        return reason
    if _stonks_engine_owner_read()!=_user_scope_id():
        return 'La prueba requiere el propietario del motor servidor'
    return ''


@app.post('/api/stonks/lifecycle-test/start')
@_stonks_serialized
def stonks_lifecycle_test_start_api():
    payload = request.get_json(silent=True) or {}
    if payload.get('confirm') is not True:
        return jsonify({'ok':False,'error':'Confirma expresamente la prueba Paper de 1 USD'}),400
    try:
        request_id = str(uuid.UUID(str(payload.get('request_id') or '')))
    except ValueError:
        return jsonify({'ok':False,'error':'Identificador de solicitud no válido'}),400
    d = _stonks_read()
    previous = next((r for r in d['position_ledger'].values() if r.get('test_request_id')==request_id and r.get('purpose')=='TEST_LIFECYCLE'), None)
    if previous:
        return jsonify({'ok':True,'paper':True,'replayed':True,'lifecycle_test':stonks_lifecycle.test_view(d)})
    reason = _stonks_test_gate(d)
    if reason or any(r.get('purpose')=='TEST_LIFECYCLE' for r in stonks_lifecycle.active_records(d)):
        return jsonify({'ok':False,'error':reason or 'Ya existe una prueba Paper activa'}),409
    me = _user_scope_id()
    with app.test_request_context('/api/stonks/decision', method='POST', json={
            'symbol':payload.get('symbol') or (d.get('engine_symbols') or ['AAPL'])[0],
            'request_id':request_id, 'signal':'BUY', 'execute':True}):
        session['zar_user_id']=me
        response = stonks_decision_api(engine=True, lifecycle_test=True)
    response = response[0] if isinstance(response,tuple) else response
    result = response.get_json()
    d = _stonks_read()
    record = next((r for r in d['position_ledger'].values() if r.get('test_request_id')==request_id),None)
    if not result.get('order_created'):
        reason = result.get('primary_reason') or 'Entrada Paper no confirmada; se reconciliará sin duplicar'
        if record:
            stonks_lifecycle.test_event(record, 'TEST_LIFECYCLE_ERROR', _stonks_audit_append, reason)
            _stonks_write(d)
        else:
            _stonks_audit_append('TEST_LIFECYCLE_ERROR', {'reason':reason,'purpose':'TEST_LIFECYCLE'})
        return jsonify({'ok':False,'paper':True,'error':reason,'lifecycle_test':stonks_lifecycle.test_view(d)}),409
    return jsonify({'ok':True,'paper':True,'lifecycle_test':stonks_lifecycle.test_view(d)}),202


@app.post('/api/stonks/lifecycle-test/close')
@_stonks_serialized
def stonks_lifecycle_test_close_api():
    payload = request.get_json(silent=True) or {}
    d = _stonks_read()
    record = d['position_ledger'].get(str(payload.get('id') or ''))
    if payload.get('confirm') is not True or not record or record.get('purpose')!='TEST_LIFECYCLE':
        return jsonify({'ok':False,'error':'Solo se permite cerrar una prueba TEST_LIFECYCLE confirmada'}),400
    if record.get('closed'):
        return jsonify({'ok':True,'paper':True,'lifecycle_test':stonks_lifecycle.test_view(d)})
    reason = _stonks_test_gate(d)
    if reason:
        return jsonify({'ok':False,'error':reason}),409
    row = d['managed_positions'].get(record['symbol'], {})
    if row.get('client_order_id')!=record['client_order_id'] or not row.get('opened_at') or record.get('ownership_conflict') or row.get('status')=='ERROR':
        return jsonify({'ok':False,'error':'La posición de prueba todavía no tiene ownership confirmado o requiere revisión'}),409
    try:
        account = _alpaca_paper_request('/v2/account')
        if account.get('status')!='ACTIVE' or account.get('trading_blocked') or account.get('account_blocked'):
            raise RuntimeError('Paper no disponible')
    except Exception:
        return jsonify({'ok':False,'error':'No se pudo verificar la conexión Alpaca Paper'}),409
    # Durable request only: the worker reconciles quantity/ownership and applies all exit Risk checks.
    if not record.get('trigger'):
        record['trigger'] = 'TEST'
        record['test_close_requested_at'] = datetime.now(timezone.utc).isoformat()
        _stonks_write(d)
    return jsonify({'ok':True,'paper':True,'lifecycle_test':stonks_lifecycle.test_view(d)}),202


'''+s[pos:]
p.write_text(s,encoding='utf-8')
