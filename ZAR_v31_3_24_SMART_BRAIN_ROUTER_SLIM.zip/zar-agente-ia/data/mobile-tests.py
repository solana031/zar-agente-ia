from pathlib import Path
p=Path('tests/stonks-rendering.cjs');s=p.read_text(encoding='utf-8')
needle='      await checkLayout();\n      await page.locator(\'.zsChatToggle\').click();'
addition='''      async function checkResponsive() {
        const issues = await page.evaluate(() => {
          const issues=[];
          const root=document.querySelector('#zarStonksApp');
          const inside=(el,label)=>{const r=el.getBoundingClientRect();if(r.left < -1 || r.right > innerWidth+1 || r.width<=0)issues.push(label+': '+JSON.stringify(r.toJSON()));};
          if(document.documentElement.scrollWidth>innerWidth)issues.push('global overflow');
          for(const selector of ['#panel','.zsTop','.zsBottom','.zsCloseBtn']){
            const el=document.querySelector(selector);inside(el,selector);
            const r=el.getBoundingClientRect();if(r.top< -1||r.bottom>innerHeight+1)issues.push(selector+' vertical overflow');
          }
          if(innerWidth<=900){
            for(const selector of ['.zsNav','.zsCard','.zsLiveCard','.zsCanvas','.zsField']){
              root.querySelectorAll(selector).forEach(el=>{if(el.getClientRects().length)inside(el,selector)});
            }
            if(getComputedStyle(document.querySelector('#chatContent .composer')).visibility!=='hidden')issues.push('main composer overlays');
            if(getComputedStyle(document.querySelector('#panel')).resize!=='none')issues.push('window resizable');
            const nav=root.querySelector('.zsNav');if(getComputedStyle(nav).overflowX!=='auto')issues.push('nav cannot scroll');
          }
          for(const table of root.querySelectorAll('table')){
            if(!table.getClientRects().length)continue;
            const wrap=table.parentElement;inside(wrap,'table wrapper');
            if(!['auto','scroll'].includes(getComputedStyle(wrap).overflowX))issues.push('table not contained');
          }
          const button=root.querySelector('.zsCloseBtn'),r=button.getBoundingClientRect();
          if(!button.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)))issues.push('close obstructed');
          return issues;
        });
        assert.deepEqual(issues,[],`${viewport.width}x${viewport.height}`);
      }
      await checkLayout();
      await checkResponsive();
      // Real clicks also scroll the compact horizontal navigation into view.
      for(const tab of ['strategies','orders','wallets','backtesting','risk','dashboard']){
        await page.locator(`[data-zstab="${tab}"]`).click();
        assert.equal(await page.locator(`#zsTab-${tab}`).isVisible(),true);
        assert.equal(await page.locator(`[data-zstab="${tab}"]`).evaluate(e=>e.classList.contains('active')),true);
        await checkResponsive();
      }
      await page.locator('#zsChatInput').fill('Mensaje de prueba sin enviar');
      assert.equal(await page.locator('#zsChatInput').inputValue(),'Mensaje de prueba sin enviar');
      await page.locator('.zsChatToggle').click();'''
assert needle in s;s=s.replace(needle,addition)
s=s.replace("      await page.locator('.zsCloseBtn').click();", "      await checkResponsive();\n      await page.locator('.zsCloseBtn').click();")
s=s.replace("      assert.equal(await page.evaluate(() => zsLiveSyncTimer), null);", "      assert.equal(await page.evaluate(() => zsLiveSyncTimer), null);\n      assert.equal(await page.locator('#chatContent .composer').evaluate(e=>getComputedStyle(e).visibility),'visible');")
p.write_text(s,encoding='utf-8')
