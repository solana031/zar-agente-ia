const fs=require('node:fs');
const {chromium}=require('playwright');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.ZAR_TEST_BROWSER});
 for(const width of [360,768,1440]){
 const page=await browser.newPage({viewport:{width,height:width===1440?900:800}});
 await page.route('**/*',r=>{const p=new URL(r.request().url()).pathname;
 if(p==='/')return r.fulfill({contentType:'text/html',body:fs.readFileSync('app/templates/index.html','utf8')});
 if(p.startsWith('/static/')&&fs.existsSync('app'+p))return r.fulfill({contentType:p.endsWith('.js')?'application/javascript':p.endsWith('.css')?'text/css':'image/png',body:fs.readFileSync('app'+p)});
 return r.fulfill({contentType:'application/json',body:JSON.stringify({ok:true,skills:[],jobs:[],events:[],files:[],tasks:[],contacts:[],messages:[],reports:[],services:[],recent:[],conversations:[],items:[],data:{current:{temperature_2m:20}},google:{connected:false}})});
 });
 page.on('pageerror',e=>console.log('JS',e.message));
 await page.goto('https://zar.test');await page.waitForTimeout(500);
 for(const [name,fn] of [['home',null],['files','showFiles'],['memory','showMemory'],['calendar','showMobileCalendar'],['tasks','showTasks'],['research','showResearch'],['settings','openZarSettings'],['studio','enterMediaEditor']]){
 await page.evaluate(()=>{closePanel();closeZarSettings();});
 if(fn)await page.evaluate(fn=>window[fn](),fn);
 await page.waitForTimeout(100);
 console.log(width,name,await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,panels:[...document.querySelectorAll('#panel,.zarOverlayCard,#mediaWorkspace')].filter(e=>e.getClientRects().length&&getComputedStyle(e).display!=='none').map(e=>({id:e.id,rect:e.getBoundingClientRect().toJSON(),scroll:e.scrollWidth,client:e.clientWidth})),outside:[...document.querySelectorAll('button,input,textarea')].filter(e=>{const r=e.getBoundingClientRect();return e.getClientRects().length&&r.width>0&&(r.left<0||r.right>innerWidth)}).slice(0,8).map(e=>e.id||e.className)})));
 if(name==='home'||name==='studio'||name==='settings')await page.screenshot({path:`data/ui-${width}-${name}.png`});
 }
 await page.close();}
 await browser.close();
})();
