from pathlib import Path
p=Path('app/main.py');s=p.read_text(encoding='utf-8');s=s.replace('from . import stonks_lifecycle','from . import stonks_lifecycle, stonks_preflight')
marker='def _stonks_test_gate(d):'
insert='''def _stonks_lifecycle_preflight(symbol):
    symbol = str(symbol or '').strip().upper()
    d = _stonks_read()
    key, secret = _alpaca_paper_credentials()
    snapshots = {}
    if key and secret:
        paths = {'account':'/v2/account', 'clock':'/v2/clock', 'positions':'/v2/positions', 'orders':'/v2/orders'}
        if stonks_preflight.valid_symbol(symbol):
            paths['asset'] = '/v2/assets/'+symbol
        for name, path in paths.items():
            try:
                value = _alpaca_paper_request(path, **({'params':{'status':'open','limit':500,'nested':'false'}} if name=='orders' else {}))
                if isinstance(value, list if name in ('positions','orders') else dict):
                    snapshots[name] = value
            except Exception:
                pass  # No broker bodies/secrets in the response; absent evidence is UNVERIFIED.
    return stonks_preflight.evaluate(d, symbol, snapshots, bool(key and secret),
                                     _stonks_engine_owner_read()==_user_scope_id())


@app.get('/api/stonks/lifecycle-test/preflight')
@_stonks_serialized
def stonks_lifecycle_test_preflight_api():
    return jsonify({'ok':True, 'paper':True, 'preflight':_stonks_lifecycle_preflight(request.args.get('symbol','AAPL'))})


'''
assert marker in s;s=s.replace(marker,insert+marker)
needle="            body={'symbol':symbol,'qty':str(qty),'side':'buy' if requested_signal=='BUY' else 'sell','type':'market','time_in_force':'day'}"
assert needle in s;s=s.replace(needle,"""            if lifecycle_test:
                preflight = _stonks_lifecycle_preflight(symbol)
                if preflight['status']!='READY':
                    return jsonify({'ok':False,'order_created':False,'primary_reason':'Pre-flight Paper no READY','preflight':preflight}),409
"""+needle)
p.write_text(s,encoding='utf-8')
p=Path('tests/test_stonks_lifecycle.py');s=p.read_text(encoding='utf-8');s=s.replace('def control_plane(directory):', "spec_pf = importlib.util.spec_from_file_location('preflight', ROOT / 'app/stonks_preflight.py')\npreflight = importlib.util.module_from_spec(spec_pf)\nspec_pf.loader.exec_module(preflight)\n\n\ndef control_plane(directory):");s=s.replace('stonks_lifecycle=lifecycle,', 'stonks_lifecycle=lifecycle, stonks_preflight=preflight,');p.write_text(s,encoding='utf-8')
p=Path('tests/test_stonks_controlled_lifecycle.py');s=p.read_text(encoding='utf-8');s=s.replace("self.account.update(status='ACTIVE', buying_power='10000')", "self.account.update(status='ACTIVE', buying_power='10000',trading_blocked=False,account_blocked=False)\n        self.state['engine_last_run']=baseline.lifecycle.now()\n        self.api['_alpaca_paper_credentials']=lambda:('mock-key','mock-secret')");p.write_text(s,encoding='utf-8')
